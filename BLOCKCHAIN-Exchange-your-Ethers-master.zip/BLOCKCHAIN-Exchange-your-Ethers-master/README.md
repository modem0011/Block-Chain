A PEER TO PEER PLATFORM TO EXCHANGE CRYPTO CURRENCIES

Steps to execute the above files:

1. You need to install solidity and it's dependencies.

2. You need to compile '.sol' files using solidity.

3. You can use Remix IDE for the above method if you do not wish to install
 Solidity and want to run this on Online IDE.

4. You can deploy using Remix IDE.

5. The video link is:  
